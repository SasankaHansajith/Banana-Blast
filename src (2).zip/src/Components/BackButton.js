// import React from "react";
// import { useNavigate } from "react-router-dom";
// import "./BackButton.css"; // Import CSS file for styles

// const BackButton = ({ position = "top-left" }) => {
//   const navigate = useNavigate(); // React Router's hook to navigate

//   const handleBack = () => {
//     navigate(-1); // Navigate to the previous page
//   };

//   return (
//     <button className={`back-button ${position}`} onClick={handleBack}>
//       &#8592; {/* Unicode arrow symbol */}
//     </button>
//   );
// };

// export default BackButton;
