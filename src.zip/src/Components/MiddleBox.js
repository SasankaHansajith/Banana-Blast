import React from "react";
import "./MiddleBox.css"; // Import the CSS file for MiddleBox styling

const MiddleBox = ({ children }) => {
  return (
    <div className="middle-box">
      {children} {/* Render children elements passed to the component */}
    </div>
  );
};

export default MiddleBox;
